import storm
# Counter is a nice way to count things,
# but it is a Python 2.7 thing
from collections import Counter


class CountBolt(storm.BasicBolt):
    # Initialize this instance
    def initialize(self, conf, context):
        self._conf = conf
        self._context = context

        # Added
        self._counter = Counter()
        # End
        storm.logInfo("Counter bolt instance starting...")

    def process(self, tup):
        # TODO
        # Task: word count
        # Hint: using instance variable to tracking the word count
        word = tup.values[0]
        self._counter[word] += 1
        count = self._counter[word]
        storm.emit([word, str(count)])
        # End


# Start the bolt when it's invoked
CountBolt().run()
