# import os
# from os.path import join
from time import sleep

# from streamparse import Spout
import storm


class FileReaderSpout(storm.Spout):
  
  def initialize(self, conf, context):
    self._conf = conf
    self._context = context
    self._complete = False
    self._data = []
    self._count = 0
    self._num = 0
    
    storm.logInfo("Spout instance starting...")
    
    with open(self._conf['input.file'], 'r') as f:
      self._data = list(f.readlines())
      self._count = len(self._data)

      
  def nextTuple(self):
    if self._num < self._count:
      storm.emit([self._data[self._num].strip()])
      self._num += 1
    else:
      sleep(1)

      



# Start the spout when it's invoked
FileReaderSpout().run()
