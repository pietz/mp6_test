import heapq
from collections import Counter

import storm

class WTuple:
    def __init__(self, word, count):
        self.word = word
        self.count = count

    def __cmp__(self, o):
        return self.count > o.count

class TopNFinderBolt(storm.BasicBolt):

    def initialize(self, conf, context):
        self._n = conf.get("top.n", 10)
        self._dict = {}
        self._heap = []

    def process(self, tup):
        word = tup.values[0]
        count = int(tup.values[1])
        new_word_count = WTuple(word, count)
        if word in self._dict:
            if count > self._dict[word].count:
                self._dict[word].count = count
                heapq.heapify(self._heap)
        elif len(self._heap) < self._n:
            self._dict[word] = new_word_count
            heapq.heappush(self._heap, new_word_count)
        else:
            smallest_word_count = self._heap[0]

            if count > smallest_word_count.count:
                del(self._dict[smallest_word_count.word])
                self._dict[word] = new_word_count
                heapq.heapreplace(self._heap, new_word_count)


        words = [x.word for x in self._heap]
        words = ", ".join(words)
        storm.emit(["top-N", word])


TopNFinderBolt().run()